import React from 'react';
import { View, Text } from 'react-native';

const HomeScreen = () => {
    return (
        <View>
            <Text>Welcome to the Home Screen!</Text>
        </View>
    );
};

export default HomeScreen;
