import React from 'react';
import { View, Text } from 'react-native';

const EntryDeleteScreen = () => {
    return (
        <View>
            <Text>Welcome to the EntryListScreen!</Text>
        </View>
    );
};

export default EntryDeleteScreen;
